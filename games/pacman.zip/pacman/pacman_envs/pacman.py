import random
import pygame
import numpy as np
from pygame.math import Vector2

class node ():
    
    def __init__ (self):
        self.g = -1 # movement cost to move from previous node to this one (usually +10)
        self.h = -1 # estimated movement cost to move from this node to the ending node (remaining horizontal and vertical steps * 10)
        self.f = -1 # total movement cost of this node (= g + h)
        # parent node - used to trace path back to the starting node at the end
        self.parent = (-1, -1)
        # node type - 0 for empty space, 1 for wall (optionally, 2 for starting node and 3 for end)
        self.type = -1 
        # create a 2d grid numpy array of 20x20



    
class Color:
    """
    Class to store hex values for colors/
    """
    def __init__(self):
        """
        Constructor Function
        """
        self.black = (0, 0, 0)
        self.grey = (100, 100, 100)
        self.white = (255, 255, 255)
        self.blue = (0, 0, 255)
        self.green = (0, 255, 0)
        self.red = (255, 0, 0)
        self.purple = (255, 0, 255)
        self.yellow = (255, 255, 0)

class PowerUp(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface([20, 20])
        self.image.fill(Color().purple)  # Color indicating special power-up
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.type = 'eat_ghosts'  # Specific type for eating ghosts
        self.duration = 7000  # Lasts for 7 seconds

    def apply_effect(self, player):
        if self.type == 'eat_ghosts':
            player.enable_ghost_eating(self.duration)


class Wall(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height, color):
        """
        Constructor function
        :param x:
        :type x:
        :param y:
        :type y:
        :param width:
        :type width:
        :param height:
        :type height:
        :param color:
        :type color:
        """

        # Call the parent's constructor
        pygame.sprite.Sprite.__init__(self)

        # Make a wall, of the size specified in the parameters
        self.image = pygame.Surface([width, height])
        self.image.fill(color)

        # Make our top-left corner the passed-in location.
        self.rect = self.image.get_rect()
        self.rect.top = y
        self.rect.left = x


class Block(pygame.sprite.Sprite):
    """
    This class represents the ball
    It derives from the "Sprite" class in Pygame
    """

    def __init__(self, color, width, height):
        """
        Constructor. Pass in the color of the block and its x and y position
        :param color:
        :type color:
        :param width:
        :type width:
        :param height:
        :type height:
        """

        # Call the parent class (Sprite) constructor
        pygame.sprite.Sprite.__init__(self)

        # Create an image of the block, and fill it with a color.
        # This could also be an image loaded from the disk.
        self.color = Color()
        self.image = pygame.Surface([width, height])
        self.image.fill(self.color.white)
        self.image.set_colorkey(self.color.white)
        pygame.draw.ellipse(self.image, color, [0, 0, width, height])

        # Fetch the rectangle object that has the dimensions of the image.
        # Update the position of this object by setting the values
        # of rect.x and rect.y
        self.rect = self.image.get_rect()


class Player(pygame.sprite.Sprite):
    """
    This class represents the bar at the bottom that the player controls
    """

    change_x = 0
    change_y = 0

    def __init__(self, x, y, filename):
        """
        Constructor function
        :param x:
        :type x:
        :param y:
        :type y:
        :param filename:
        :type filename:
        """

        # Call the parent's constructor
        pygame.sprite.Sprite.__init__(self)

        # Set height, width
        self.image = pygame.image.load(filename).convert()

        # Make our top-left corner the passed-in location.
        self.rect = self.image.get_rect()
        self.rect.top = y
        self.rect.left = x
        self.prev_x = x
        self.prev_y = y
        self.goal = None
        self.ghost_eating = False
        self.position = Vector2(x, y)  # Current position as a vector
        self.goal = Vector2()  # Goal position initialized to zero vector
        self.directions = {
            'up': Vector2(0, -1),
            'down': Vector2(0, 1),
            'left': Vector2(-1, 0),
            'right': Vector2(1, 0)
        }


    def prev_direction(self):
        """
        Clear the speed of the player
        """
        self.prev_x = self.change_x
        self.prev_y = self.change_y

    def change_speed(self, x, y):
        """
        Change the speed of the player
        :param x:
        :type x:
        :param y:
        :type y:
        """
        self.change_x += x
        self.change_y += y

    def update(self, walls, gate):
        """
        Find a new position for the player
        :param walls: 
        :type walls: 
        :param gate: 
        :type gate: 
        """
        for event in pygame.event.get():
            if event.type == pygame.USEREVENT + 3:  # Timer for ghost eating power-up
                self.ghost_eating = False
        # Get the old position, in case we need to go back to it
        old_x = self.rect.left
        new_x = old_x + self.change_x
        self.rect.left = new_x

        old_y = self.rect.top
        new_y = old_y + self.change_y

   
        x_collide = pygame.sprite.spritecollide(self, walls, False)
        if x_collide:
            self.rect.left = old_x
        else:
            self.rect.top = new_y
            y_collide = pygame.sprite.spritecollide(self, walls, False)
            if y_collide:
                self.rect.top = old_y

        if gate:
            gate_hit = pygame.sprite.spritecollide(self, gate, False)
            if gate_hit:
                self.rect.left = old_x
                self.rect.top = old_y 
    
    def enable_ghost_eating(self, duration):
        self.ghost_eating = True
        pygame.time.set_timer(pygame.USEREVENT + 3, duration)

    


class Ghost(Player):
    """
    Class to handle ghosts, inheriting from Player.
    """
    def __init__(self, x, y, filename, game):
        super().__init__(x, y, filename)
        self.game = game

    def update_behavior(self, pacman):
        self.mode = "flee" if pacman.ghost_eating else "chase"

    def move(self, pacman):
        self.update_behavior(pacman)
        direction = self.chase_pacman() if self.mode == "chase" else self.run_away_from_pacman()
        if direction:
            movement = self.calculate_movement(direction)
            self.change_speed(*movement)

    def chase_pacman(self):
        return self.goal_direction(self.game.game_map)

    def run_away_from_pacman(self):
        furthest_point = self.find_furthest_point()
        self.set_goal(*furthest_point)
        return self.goal_direction(self.game.game_map)

    def find_furthest_point(self):
        max_distance = 0
        furthest_point = (self.rect.x, self.rect.y)
        for y in range(self.game.path_finder.size[0]):
            for x in range(self.game.path_finder.size[1]):
                if self.game.game_map[y][x] == 0:
                    distance = (Vector2(x, y) - self.position).length_squared()
                    if distance > max_distance:
                        max_distance = distance
                        furthest_point = (x, y)
        return furthest_point

    def goal_direction(self, game_map):
        TILEWIDTH = 30
        distances = []
        directions = list(self.directions.keys())
        for direction in directions:
            next_position = self.position + self.directions[direction] * TILEWIDTH
            if game_map[int(next_position.y // TILEWIDTH)][int(next_position.x // TILEWIDTH)] == 1:
                distances.append(float('inf'))
            else:
                vec = next_position - self.goal
                distances.append(vec.length_squared())
        if min(distances) == float('inf'):
            return None
        else:
            index = distances.index(min(distances))
            return directions[index]

    def calculate_movement(self, direction):
        movement_map = {
            'up': (0, -30),
            'down': (0, 30),
            'left': (-30, 0),
         'right': (30, 0)
        }
        return movement_map.get(direction, (0, 0)) 
    

class Game:
    """
    Class to run the game.
    """

    def __init__(self):
        """
        Constructor Function
        """
        self.cell_size = 30
        self.grid_width = 20
        self.grid_height = 20
        #self.path_finder = path_finder()
        # This is a list of walls. Each is in the form [x, y, width, height]
        self.walls = [
            [0, 0, 6, 600],
            [0, 0, 600, 6],
            [0, 600, 606, 6],
            [600, 0, 6, 606],
            [300, 0, 6, 66],
            [60, 60, 186, 6],
            [360, 60, 186, 6],
            [60, 120, 66, 6],
            [60, 120, 6, 126],
            [180, 120, 246, 6],
            [300, 120, 6, 66],
            [480, 120, 66, 6],
            [540, 120, 6, 126],
            [120, 180, 126, 6],
            [120, 180, 6, 126],
            [360, 180, 126, 6],
            [480, 180, 6, 126],
            [180, 240, 6, 126],
            [180, 360, 246, 6],
            [420, 240, 6, 126],
            [240, 240, 42, 6],
            [324, 240, 42, 6],
            [240, 240, 6, 66],
            [240, 300, 126, 6],
            [360, 240, 6, 66],
            [0, 300, 66, 6],
            [540, 300, 66, 6],
            [60, 360, 66, 6],
            [60, 360, 6, 186],
            [480, 360, 66, 6],
            [540, 360, 6, 186],
            [120, 420, 366, 6],
            [120, 420, 6, 66],
            [480, 420, 6, 66],
            [180, 480, 246, 6],
            [300, 480, 6, 66],
            [120, 540, 126, 6],
            [360, 540, 126, 6],
        ]

       

        self.color = Color()
        # Call this function so the Pygame library can initialize itself
        pygame.init()

        # Create an 606x606 sized screen
        self.screen = pygame.display.set_mode([606, 606])

        # Set the title of the window
        pygame.display.set_caption('Pacman')

        # Create a surface we can draw on
        background = pygame.Surface(self.screen.get_size())
        background = background.convert()
        background.fill(self.color.black)
        self.clock = pygame.time.Clock()
        pygame.font.init()
        self.font = pygame.font.SysFont('arial', 30)
        self.all_sprites_list = None
        self.power_pellets = pygame.sprite.RenderPlain()
        # default locations for Pacman and ghosts
        w = 303 - 16  # Width
        p_h = 7 * 60 + 19
        m_h = 4 * 60 + 19
        b_h = 3 * 60 + 19
        i_w = 303 - 16 - 32
        c_w = 303 + 32 - 16

        self.all_sprites_list = pygame.sprite.RenderPlain()
        self.block_list = pygame.sprite.RenderPlain()
        self.ghost_list = pygame.sprite.RenderPlain()
        self.pacman_collide = pygame.sprite.RenderPlain()
        self.wall_list = self.setup_walls()

        self.gate = self.setup_gate()

        p_turn = 0
        p_steps = 0

        b_turn = 0
        b_steps = 0

        i_turn = 0
        i_steps = 0

        c_turn = 0
        c_steps = 0

        # Create the player  object
        self.pacman = Player(w, p_h, 'images/pacman.png')
        self.all_sprites_list.add(self.pacman)
        self.pacman_collide.add(self.pacman)

        self.ghost_two = Ghost(w, b_h, 'images/red.png', self)
        self.ghost_list.add(self.ghost_two)
        self.all_sprites_list.add(self.ghost_two)

        self.ghost_one = Ghost(w, m_h, 'images/pink.png', self)
        self.ghost_list.add(self.ghost_one)
        self.all_sprites_list.add(self.ghost_one)

        ghost_three = Ghost(i_w, m_h, 'images/blue.png',self)
        self.ghost_list.add(ghost_three)
        self.all_sprites_list.add(ghost_three)

        ghost_four = Ghost(c_w, m_h, 'images/yellow.png',self)
        self.ghost_list.add(ghost_four)
        self.all_sprites_list.add(ghost_four)
        grid = [[0 for _ in range(19)] for _ in range(19)]
        # Draw the grid
        for row in range(19):
            for column in range(19):
                
                if (row == 7 or row == 8) and (column == 8 or column == 9 or column == 10):
                    continue
                else:
                    block = Block(self.color.yellow, 4, 4)

                    # Set a random location for the block
                    block.rect.x = 30 * column + 6 + 26
                    block.rect.y = 30 * row + 6 + 26

                    b_collide = pygame.sprite.spritecollide(block, self.wall_list, False)
                    p_collide = pygame.sprite.spritecollide(block, self.pacman_collide, False)
                    if b_collide:
                        grid[row][column] = 1

                        continue

                    elif p_collide:
                        grid[row][column] = 0
                        continue
                    else:
                        # Add the block to the list of objects
                        grid[row][column] = 0
                        self.block_list.add(block)
                        self.all_sprites_list.add(block)
        # create new grid which is 20x20 with edges as 1 from grid
        
        new_grid = [[1 if i == 0 or i == 19 or j == 0 or j == 19 else grid[i-1][j-1] for j in range(20)] for i in range(20)] 
        self.game_map = new_grid
        self.path_finder.ResizeMap(20, 20)
        self.update_path_finder_with_walls(new_grid)
        blocks = list(self.block_list)
        selected_blocks = random.sample(blocks, 4)
        self.power_pellet_list = pygame.sprite.RenderPlain()
# Replace the selected blocks with power pellets
        for block in selected_blocks:
            power_pellet = PowerUp(block.rect.x, block.rect.y)  # Assuming you have a PowerPellet class
            self.power_pellet_list.add(power_pellet)
    # Add the power pellet to the game (you might need to modify this part based on your game structure)
            self.all_sprites_list.add(power_pellet)
        self.bll = len(self.block_list)


   

    def update_path_finder_with_walls(self, grid):
        for i in range(len(grid[0])):
            for j in range(len(grid[1])):
                self.path_finder.SetType(i,j, grid[i][j])



    def get_maze_size(self):
        max_width = 0
        max_height = 0

        for wall in self.walls:
            x, y, width, height = wall
            # Calculate the furthest extents of the walls
            max_width = max(max_width, x + width)
            max_height = max(max_height, y + height)

        return max_width, max_height
    def setup_walls(self):
        """
        Make the walls. (x_pos, y_pos, width, height)
        :return:
        :rtype:
        """
        wall_list = pygame.sprite.RenderPlain()

        # Loop through the list. Create the wall, add it to the list
        for item in self.walls:
            wall = Wall(item[0], item[1], item[2], item[3], self.color.grey)
            wall_list.add(wall)
            self.all_sprites_list.add(wall)

        # return our new list
        return wall_list

    def setup_gate(self):
        """
        Add gates in the walls
        :return:
        :rtype:
        """
        gate = pygame.sprite.RenderPlain()
        gate.add(Wall(282, 242, 42, 2, self.color.white))
        self.all_sprites_list.add(gate)
        return gate 
    

    def setup_power_pellets(self):
        # Define power pellet locations and add them to the game
        locations = [(100, 200), (500, 300), (300, 100)]  # Example locations
        for x, y in locations:
            pellet = PowerUp(x, y)
            self.power_pellets.add(pellet)
            self.all_sprites_list.add(pellet) 


    def start_game(self):
        """
        start the game
        """

       

        
                
       

        # Get the unique row indices

        
        score = 0
        done = False
        while not done:
            # Events
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    done = True

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT:
                        self.pacman.change_speed(-30, 0)
                    if event.key == pygame.K_RIGHT:
                        self.pacman.change_speed(30, 0)
                    if event.key == pygame.K_UP:
                        self.pacman.change_speed(0, -30)
                    if event.key == pygame.K_DOWN:
                        self.pacman.change_speed(0, 30)

                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_LEFT:
                        self.pacman.change_speed(30, 0)
                    if event.key == pygame.K_RIGHT:
                        self.pacman.change_speed(-30, 0)
                    if event.key == pygame.K_UP:
                        self.pacman.change_speed(0, 30)
                    if event.key == pygame.K_DOWN:
                        self.pacman.change_speed(0, -30)

            self.pacman.update(self.wall_list, self.gate) 

            # Assuming new_grid is your grid
            

            # Check if the two grids are the same
            # print(f"new_grid_np: {new_grid_np}")
            # print(f"path_finder_grid: {path_finder_grid}")
            # print(f"Are the grids equal? {are_grids_equal}")
        # whic
            #self.ghost_one.move(self.pacman)
            self.ghost_two.move(self.pacman)
            # ghost_three.move(pacman)
            # ghost_four.move(pacman)

            # ghost_one.update(wall_list, None)
            self.ghost_two.update(self.wall_list, None)
            print(f"Ghost Two position: {self.ghost_two.rect.x}, {self.ghost_two.rect.y}")
            print("Is Ghost Two in all_sprites_list?", self.ghost_two in self.all_sprites_list)
            print("Is Ghost Two in ghost_list?", self.ghost_two in self.ghost_list)
            # ghost_three.update(wall_list, None)
            # ghost_four.update(wall_list, None)
            # See if the pacman block has collided with anything.
            blocks_hit_list = pygame.sprite.spritecollide(self.pacman, self.block_list, True) 
            power_pellets_hit_list = pygame.sprite.spritecollide(self.pacman, self.power_pellet_list, True)
            # check if pacman hits any power pellet
            # if pellet is hit 
            # Check the list of collisions.
            if len(blocks_hit_list) > 0:
                score += len(blocks_hit_list)

            self.screen.fill(self.color.black)

            self.wall_list.draw(self.screen)
            self.gate.draw(self.screen)
            self.all_sprites_list.draw(self.screen)
            self.ghost_list.draw(self.screen)

            text = self.font.render(str(score) + '/' + str(self.bll), True, self.color.white)
            self.screen.blit(text, [270, 254])

            if score == self.bll:
                self.do_next(
                    'Congratulations, you won!',
                    145,
                    self.block_list,
                    self.ghost_list,
                    self.pacman_collide,
                    self.wall_list,
                    self.gate,
                )
                return

            ghost_hit_list = pygame.sprite.spritecollide(self.pacman, self.ghost_list, False)

            if ghost_hit_list:
                self.do_next(
                    'Game Over',
                    235,
                    self.block_list,
                    self.ghost_list,
                    self.pacman_collide,
                    self.wall_list,
                    self.gate,
                )
                return

            pygame.display.flip()

            self.clock.tick(10)

    def do_next(self, message, left, block_list, ghost_list, pacman_collide, wall_list, gate):
        """
        Go to next configuration in the game
        :param message:
        :type message:
        :param left:
        :type left:
        :param block_list:
        :type block_list:
        :param ghost_list:
        :type ghost_list:
        :param pacman_collide:
        :type pacman_collide:
        :param wall_list:
        :type wall_list:
        :param gate:
        :type gate:
        """
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        pygame.quit()
                        return
                    if event.key == pygame.K_RETURN:
                        del self.all_sprites_list
                        del block_list
                        del ghost_list
                        del pacman_collide
                        del wall_list
                        del gate
                        self.start_game()
                        return

            # Grey background
            w_surface = pygame.Surface((400, 200))  # the size of your rect
            w_surface.fill((255, 255, 255))  # this fills the entire surface
            self.screen.blit(w_surface, (100, 200))  # (0,0) are the top-left coordinates

            # Won or lost
            text1 = self.font.render(message, True, self.color.black)
            self.screen.blit(text1, [left, 233])

            text2 = self.font.render('To play again, press ENTER.', True, self.color.black)
            self.screen.blit(text2, [135, 300])
            text3 = self.font.render('To quit, press ESCAPE.', True, self.color.black)
            self.screen.blit(text3, [165, 340])

            pygame.display.flip()
            self.clock.tick(10)


if __name__ == '__main__':
    # main function
    game = Game()
    game.start_game()
    pygame.quit()