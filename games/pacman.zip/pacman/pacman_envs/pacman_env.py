import gymnasium as gym
from gymnasium import spaces
import pygame
import numpy as np
import os
import sys
from pygame.locals import *
import time
from collections import deque
from skimage.color import rgb2gray
from skimage.transform import resize
from stable_baselines3 import PPO

# Import your game modules
from games.pacman.pacman_envs.player import pacman
from games.pacman.pacman_envs.ghost import ghost
from games.pacman.pacman_envs.path import path_finder
from games.pacman.pacman_envs.level import level
from games.pacman.pacman_envs.game import game
from games.pacman.pacman_envs.fruit import fruit
from games.pacman.pacman_envs.config import *
import networkx as nx
import torch

class PacmanEnv(gym.Env):
    metadata = {'render_modes': ['human', 'rgb_array']}
    
    def __init__(self, render_mode='human', observation_type='pixel'):
        super(PacmanEnv, self).__init__()

        self.render_mode = render_mode
        self.observation_type = observation_type

        # Action space (4 directions)
        self.action_space = spaces.Discrete(4)  # [Up, Down, Left, Right]

        # Observation space
        self.frame_stack = 4
        self.window_width = 23*16  # Updated to match the actual game window width
        self.window_height = 23*16  # Updated to match the actual game window height
        if observation_type == 'pixel':
            self.observation_space = spaces.Box(low=0, high=255,
                                                shape=(self.frame_stack, 84, 84),
                                                dtype=np.uint8)
        else:
            self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(201, 8), dtype=np.float32)  # Adjust based on fixed object size

        # Initialize the game
        pygame.init()
        self.window = pygame.display.set_mode((self.window_width, self.window_height), pygame.DOUBLEBUF | pygame.HWSURFACE)
        pygame.display.set_caption("Pacman")
        self.screen = pygame.display.get_surface()
        self.frame_buffer = deque(maxlen=self.frame_stack)

        self.tileID = {}
        self.tileIDName = {}
        self.tileIDImage = {}
        self.NO_GIF_TILES = set()
        self.path = path_finder()
        self.player = pacman(self.path, self.screen)
        self.ghosts = {i: ghost(i, self.path, self.screen, self.player) for i in range(6)}
        self.fruit = fruit()
        self.game = game(self.fruit, self.player, self.screen)
        self.level = level(self.game, self.player, self.ghosts, self.path, self.fruit, self.screen)
    
        self.load_resources()

    def load_resources(self):
        lineNum = 0
        self.SCRIPT_PATH = os.path.dirname(__file__)
        res_path = os.path.join(self.SCRIPT_PATH, "res")
        # Load background images
        self.img_Background = pygame.image.load(os.path.join(res_path, "backgrounds", "1.gif")).convert()
        
        f = open(os.path.join(self.SCRIPT_PATH, "res", "crossref.txt"), 'r')

        # Load tile images and other assets by initializing the cross-reference data structures
        for i in f.readlines():
            while len(i) > 0 and (i[-1] == '\n' or i[-1] == '\r'):
                i = i[:-1]
            while len(i) > 0 and (i[0] == '\n' or i[0] == '\r'):
                i = i[1:]
            str_splitBySpace = i.split(' ')
            
            j = str_splitBySpace[0]
                
            if j == "'" or j == "" or j == "#":
                useLine = False
            else:
                useLine = True
            
            if useLine == True:
                self.tileIDName[int(str_splitBySpace[0])] = str_splitBySpace[1]
                self.tileID[str_splitBySpace[1]] = int(str_splitBySpace[0])
                
                thisID = int(str_splitBySpace[0])
                if thisID not in self.NO_GIF_TILES:
                    self.tileIDImage[thisID] = pygame.image.load(os.path.join(self.SCRIPT_PATH, "res", "tiles", str_splitBySpace[1] + ".gif")).convert()
                else:
                    self.tileIDImage[thisID] = pygame.Surface((16, 16))
                
                # Change colors in tileIDImage to match maze colors
                for y in range(0, 16, 1):
                    for x in range(0, 16, 1):
                        if self.tileIDImage[thisID].get_at((x, y)) == (255, 206, 255, 255):
                            self.tileIDImage[thisID].set_at((x, y), self.level.edgeLightColor)
                        elif self.tileIDImage[thisID].get_at((x, y)) == (132, 0, 132, 255):
                            self.tileIDImage[thisID].set_at((x, y), self.level.fillColor)
                        elif self.tileIDImage[thisID].get_at((x, y)) == (255, 0, 255, 255):
                            self.tileIDImage[thisID].set_at((x, y), self.level.edgeShadowColor)
                        elif self.tileIDImage[thisID].get_at((x, y)) == (128, 0, 128, 255):
                            self.tileIDImage[thisID].set_at((x, y), self.level.pelletColor)
            lineNum += 1

    def seed(self, seed=None):
        self.np_random, seed = gym.utils.seeding.np_random(seed)
        random.seed(seed)
        np.random.seed(seed)
        return [seed]

    def reset(self, seed=None, options=None):
        super().reset(seed=seed, options=options)
        if seed is not None:
            self.seed(seed)
        # Reset the game
        self.player = pacman(self.path, self.screen)
        self.ghosts = {i: ghost(i, self.path, self.screen, self.player) for i in range(6)}
        self.fruit = fruit()
        self.game = game(self.fruit, self.player, self.screen)
        self.level = level(self.game, self.player, self.ghosts, self.path, self.fruit, self.screen)
        self.load_resources()

        self.clock = pygame.time.Clock()
        self.game.StartNewGame(self.level, self.tileID, self.tileIDImage, self.tileIDName)
        self.level.LoadLevel(self.game.GetLevelNum(), self.tileID, self.tileIDImage, self.tileIDName)
        self.window = pygame.display.set_mode(self.game.screenSize, pygame.DOUBLEBUF | pygame.HWSURFACE)
        self.frame_buffer.clear()

        obs = self._get_observation()
        for _ in range(self.frame_stack):
            self.frame_buffer.append(obs)
        return np.array(self.frame_buffer), {}

    def step(self, action):
        reward = 0
        terminated = False
        truncated = False

        # Map action to game controls
        if self.game.mode == 1:
            if action == 0 and not self.level.CheckIfHitWall(self.player.x + self.player.speed, self.player.y, self.player.nearestRow, self.player.nearestCol):
                self.player.velX = self.player.speed
                self.player.velY = 0
            elif action == 1 and not self.level.CheckIfHitWall(self.player.x - self.player.speed, self.player.y, self.player.nearestRow, self.player.nearestCol):
                self.player.velX = -self.player.speed
                self.player.velY = 0
            elif action == 2 and not self.level.CheckIfHitWall(self.player.x, self.player.y + self.player.speed, self.player.nearestRow, self.player.nearestCol):
                self.player.velX = 0
                self.player.velY = self.player.speed
            elif action == 3 and not self.level.CheckIfHitWall(self.player.x, self.player.y - self.player.speed, self.player.nearestRow, self.player.nearestCol):
                self.player.velX = 0
                self.player.velY = -self.player.speed

            score = self.game.score
            self.game.modeTimer += 1
            self.player.Move(self.game, self.level, self.ghosts, self.fruit, self.tileID)
            for ghost in self.ghosts.values():
                ghost.Move(self.level, self.tileID)
           
            new_score = self.game.score

            reward = new_score - score  # Reward for eating pellets

        elif self.game.mode == 2:
            reward = -100
            self.level.Restart(self.tileID)
            self.game.lives -= 1
            if self.game.lives == -1:
                terminated = True
            
        elif self.game.mode == 5:
            reward = 100
            self.game.mode = 1
        
        elif self.game.mode == 6:
            reward = 1000
            terminated = True
        self.game.SmartMoveScreen(self.level)
        obs = self._get_observation()
        self.frame_buffer.append(obs)
        stacked_obs = np.array(self.frame_buffer)
        return stacked_obs, reward, terminated, truncated, {}

    def _get_observation(self):
        frame = pygame.surfarray.array3d(pygame.display.get_surface())
        frame = frame.transpose((1, 0, 2))  # Correct the shape to (height, width, channels)
        frame = rgb2gray(frame)  # Convert to grayscale
        frame = resize(frame, (84, 84), anti_aliasing=True).astype(np.uint8)  # Resize and convert to uint8
        return frame

    def render(self, mode='human'):
        self.screen.blit(self.img_Background, (0, 0))
        self.level.DrawMap(self.tileID, self.tileIDImage)
        
        if self.game.fruitScoreTimer > 0:
            if self.game.modeTimer % 2 == 0:
                self.game.DrawNumber (2500, self.fruit.x - self.game.screenPixelPos[0] - 16, self.fruit.y - self.screenPixelPos[1] + 4)

        for i in range(0, 4, 1):
            self.ghosts[i].Draw(self.game, self.tileID, self.tileIDImage, self.ghosts)
        self.fruit.Draw(self.game)
        self.player.Draw(self.game)
        if mode == 'human':
            pygame.display.flip()
            self.clock.tick(60)
        elif mode == 'rgb_array':
            return pygame.surfarray.array3d(pygame.display.get_surface())

    def close(self):
        pygame.quit()

# Usage Example
if __name__ == "__main__":
    env = PacmanEnv(render_mode='human', observation_type='pixel')
    obs,_ = env.reset()
    done = False
    model = PPO.load("ppo_pacman_pixel")
    while not done:
        action, _ = model.predict(obs)
        obs, reward, done, _, info = env.step(action)
        env.render()
        if reward < 0:
            print("Ghost collision")
        if done:
            print("Game Over. Restarting...")
            obs,_ = env.reset()
            done = False

    env.close()

