#! /usr/bin/python

# pacman.pyw
# By David Reilly

# Modified by Andy Sommerville, 8 October 2007:
# - Changed hard-coded DOS paths to os.path calls
# - Added constant SCRIPT_PATH (so you don't need to have pacman.pyw and res in your cwd, as long
# -   as those two are in the same directory)
# - Changed text-file reading to accomodate any known EOLn method (\n, \r, or \r\n)
# - I (happily) don't have a Windows box to test this. Blocks marked "WIN???"
# -   should be examined if this doesn't run in Windows
# - Added joystick support (configure by changing JS_* constants)
# - Added a high-score list. Depends on wx for querying the user's name

import pygame, sys, os, random
from pygame.locals import *
from games.pacman.pacman_envs.player import pacman
from games.pacman.pacman_envs.ghost import ghost
from games.pacman.pacman_envs.path import path_finder
from games.pacman.pacman_envs.level import level
from games.pacman.pacman_envs.game import game
from games.pacman.pacman_envs.fruit import fruit
from games.pacman.pacman_envs.config import *


window = pygame.display.set_mode((1, 1))
pygame.display.set_caption("Pacman")

screen = pygame.display.get_surface()

img_Background = pygame.image.load(os.path.join(SCRIPT_PATH,"res","backgrounds","1.gif")).convert()

snd_pellet = {}
snd_pellet[0] = pygame.mixer.Sound(os.path.join(SCRIPT_PATH,"res","sounds","pellet1.wav"))
snd_pellet[1] = pygame.mixer.Sound(os.path.join(SCRIPT_PATH,"res","sounds","pellet2.wav"))
snd_powerpellet = pygame.mixer.Sound(os.path.join(SCRIPT_PATH,"res","sounds","powerpellet.wav"))
snd_eatgh = pygame.mixer.Sound(os.path.join(SCRIPT_PATH,"res","sounds","eatgh2.wav"))
snd_fruitbounce = pygame.mixer.Sound(os.path.join(SCRIPT_PATH,"res","sounds","fruitbounce.wav"))
snd_eatfruit = pygame.mixer.Sound(os.path.join(SCRIPT_PATH,"res","sounds","eatfruit.wav"))
snd_extralife = pygame.mixer.Sound(os.path.join(SCRIPT_PATH,"res","sounds","extralife.wav"))



#      ___________________
# ___/  class definitions  \_______________________________________________

def CheckIfCloseButton(events):
    for event in events: 
        if event.type == pygame.QUIT: 
            sys.exit(0)


def CheckInputs(): 
    
    if thisGame.mode == 1:
        if pygame.key.get_pressed()[ pygame.K_RIGHT ] or (js!=None and js.get_axis(JS_XAXIS)>0):
            if not thisLevel.CheckIfHitWall(player.x + player.speed, player.y, player.nearestRow, player.nearestCol): 
                player.velX = player.speed
                player.velY = 0
                
        elif pygame.key.get_pressed()[ pygame.K_LEFT ] or (js!=None and js.get_axis(JS_XAXIS)<0):
            if not thisLevel.CheckIfHitWall(player.x - player.speed, player.y, player.nearestRow, player.nearestCol): 
                player.velX = -player.speed
                player.velY = 0
            
        elif pygame.key.get_pressed()[ pygame.K_DOWN ] or (js!=None and js.get_axis(JS_YAXIS)>0):
            if not thisLevel.CheckIfHitWall(player.x, player.y + player.speed, player.nearestRow, player.nearestCol): 
                player.velX = 0
                player.velY = player.speed
            
        elif pygame.key.get_pressed()[ pygame.K_UP ] or (js!=None and js.get_axis(JS_YAXIS)<0):
            if not thisLevel.CheckIfHitWall(player.x, player.y - player.speed, player.nearestRow, player.nearestCol):
                player.velX = 0
                player.velY = -player.speed
                
    if pygame.key.get_pressed()[ pygame.K_ESCAPE ]:
        sys.exit(0)
            
    elif thisGame.mode == 4 :
        if pygame.key.get_pressed()[ pygame.K_RETURN ] or (js!=None and js.get_button(JS_STARTBUTTON)):
            thisGame.StartNewGame(thisLevel, tileID, tileIDImage, tileIDName)
            
    
def GetCrossRef ():

    f = open(os.path.join(SCRIPT_PATH,"res","crossref.txt"), 'r')
    # ANDY -- edit
    #fileOutput = f.read()
    #str_splitByLine = fileOutput.split('\n')

    lineNum = 0
    useLine = False

    for i in f.readlines():
        # print " ========= Line " + str(lineNum) + " ============ "
        while len(i)>0 and (i[-1]=='\n' or i[-1]=='\r'): i=i[:-1]
        while len(i)>0 and (i[0]=='\n' or i[0]=='\r'): i=i[1:]
        str_splitBySpace = i.split(' ')
        
        j = str_splitBySpace[0]
            
        if (j == "'" or j == "" or j == "#"):
            # comment / whitespace line
            # print " ignoring comment line.. "
            useLine = False
        else:
            # print str(wordNum) + ". " + j
            useLine = True
        
        if useLine == True:
            tileIDName[ int(str_splitBySpace[0]) ] = str_splitBySpace[1]
            tileID[ str_splitBySpace[1] ] = int(str_splitBySpace[0])
            
            thisID = int(str_splitBySpace[0])
            if not thisID in NO_GIF_TILES:
                tileIDImage[ thisID ] = pygame.image.load(os.path.join(SCRIPT_PATH,"res","tiles",str_splitBySpace[1] + ".gif")).convert()
            else:
                    tileIDImage[ thisID ] = pygame.Surface((16,16))
            
            # change colors in tileIDImage to match maze colors
            for y in range(0, 16, 1):
                for x in range(0, 16, 1):
                
                    if tileIDImage[ thisID ].get_at( (x, y) ) == (255, 206, 255, 255):
                        # wall edge
                        tileIDImage[ thisID ].set_at( (x, y), thisLevel.edgeLightColor )
                        
                    elif tileIDImage[ thisID ].get_at( (x, y) ) == (132, 0, 132, 255):
                        # wall fill
                        tileIDImage[ thisID ].set_at( (x, y), thisLevel.fillColor ) 
                        
                    elif tileIDImage[ thisID ].get_at( (x, y) ) == (255, 0, 255, 255):
                        # pellet color
                        tileIDImage[ thisID ].set_at( (x, y), thisLevel.edgeShadowColor )   
                        
                    elif tileIDImage[ thisID ].get_at( (x, y) ) == (128, 0, 128, 255):
                        # pellet color
                        tileIDImage[ thisID ].set_at( (x, y), thisLevel.pelletColor )   
                
            # print str_splitBySpace[0] + " is married to " + str_splitBySpace[1]
        lineNum += 1

    
#      _____________________________
#      __________________
# ___/  main code block  \_____________________________________________________
# create a path_finder object

f = open(os.path.join(SCRIPT_PATH,"res","crossref.txt"), 'r')
# ANDY -- edit
#fileOutput = f.read()
#str_splitByLine = fileOutput.split('\n')

lineNum = 0
useLine = False

tileIDName = {} # gives tile name (when the ID# is known)
tileID = {} # gives tile ID (when the name is known)
tileIDImage = {} # gives tile image (when the ID# is known)


path = path_finder()

# create pacman object
player = pacman(path, screen)

# create ghost objects
ghosts = {}
for i in range(0, 6, 1):
    # remember, ghost[4] is the blue, vulnerable ghost
    ghosts[i] = ghost(i, path, screen, player)
    
# create piece of fruit
thisFruit = fruit() 





# create game and level objects and load first level
thisGame = game(thisFruit, player, screen)
print("thisGame", thisGame.screenSize)
thisLevel = level( thisGame, player, ghosts, path, thisFruit, screen)
for i in f.readlines():
    # print " ========= Line " + str(lineNum) + " ============ "
    while len(i)>0 and (i[-1]=='\n' or i[-1]=='\r'): i=i[:-1]
    while len(i)>0 and (i[0]=='\n' or i[0]=='\r'): i=i[1:]
    str_splitBySpace = i.split(' ')
    
    j = str_splitBySpace[0]
        
    if (j == "'" or j == "" or j == "#"):
        # comment / whitespace line
        # print " ignoring comment line.. "
        useLine = False
    else:
        # print str(wordNum) + ". " + j
        useLine = True
    
    if useLine == True:
        tileIDName[ int(str_splitBySpace[0]) ] = str_splitBySpace[1]
        tileID[ str_splitBySpace[1] ] = int(str_splitBySpace[0])
        
        thisID = int(str_splitBySpace[0])
        if not thisID in NO_GIF_TILES:
            tileIDImage[ thisID ] = pygame.image.load(os.path.join(SCRIPT_PATH,"res","tiles",str_splitBySpace[1] + ".gif")).convert()
        else:
                tileIDImage[ thisID ] = pygame.Surface((16,16))
        
        # change colors in tileIDImage to match maze colors
        for y in range(0, 16, 1):
            for x in range(0, 16, 1):
            
                if tileIDImage[ thisID ].get_at( (x, y) ) == (255, 206, 255, 255):
                    # wall edge
                    tileIDImage[ thisID ].set_at( (x, y), thisLevel.edgeLightColor )
                    
                elif tileIDImage[ thisID ].get_at( (x, y) ) == (132, 0, 132, 255):
                    # wall fill
                    tileIDImage[ thisID ].set_at( (x, y), thisLevel.fillColor ) 
                    
                elif tileIDImage[ thisID ].get_at( (x, y) ) == (255, 0, 255, 255):
                    # pellet color
                    tileIDImage[ thisID ].set_at( (x, y), thisLevel.edgeShadowColor )   
                    
                elif tileIDImage[ thisID ].get_at( (x, y) ) == (128, 0, 128, 255):
                    # pellet color
                    tileIDImage[ thisID ].set_at( (x, y), thisLevel.pelletColor )   
            
        # print str_splitBySpace[0] + " is married to " + str_splitBySpace[1]
    lineNum += 1
thisLevel.LoadLevel( thisGame.GetLevelNum(), tileID, tileIDImage, tileIDName )
thisGame.StartNewGame( thisLevel, tileID, tileIDImage, tileIDName )

window = pygame.display.set_mode( thisGame.screenSize, pygame.DOUBLEBUF | pygame.HWSURFACE )

# initialise the joystick
if pygame.joystick.get_count()>0:
  if JS_DEVNUM<pygame.joystick.get_count(): js=pygame.joystick.Joystick(JS_DEVNUM)
  else: js=pygame.joystick.Joystick(0)
  js.init()
else: js=None   

while True: 

    CheckIfCloseButton( pygame.event.get() )
    
    if thisGame.mode == 1:
        # normal gameplay mode
        CheckInputs()
        
        thisGame.modeTimer += 1
        player.Move(thisGame, thisLevel, ghosts, thisFruit, tileID)
        
        for i in range(0, 4, 1):
            ghosts[i].Move(thisLevel, tileID)
        thisFruit.Move(thisGame)
            
    elif thisGame.mode == 2:
        # waiting after getting hit by a ghost
        thisGame.modeTimer += 1
        
        if thisGame.modeTimer == 90:
            # close the game
            #pygame.quit()
            thisLevel.Restart(tileID)
            
            thisGame.lives -= 1
            if thisGame.lives == -1:
                thisGame.updatehiscores(thisGame.score)
                thisGame.SetMode( 3 )
                thisGame.drawmidgamehiscores()
            else:
                thisGame.SetMode( 4 )
                
    elif thisGame.mode == 3:
        # game over
        print("Game Over")
        running = False
        #pygame.quit()
        CheckInputs()
            
    elif thisGame.mode == 4:
        # waiting to start
        print("Waiting to start")
        thisGame.modeTimer += 1
        
        if thisGame.modeTimer == 90:
            thisGame.SetMode( 1 )
            player.velX = player.speed
            
    elif thisGame.mode == 5:
        # brief pause after munching a vulnerable ghost
        thisGame.modeTimer += 1
        
        if thisGame.modeTimer == 30:
            thisGame.SetMode( 1 )
            
    elif thisGame.mode == 6:
        # pause after eating all the pellets
        thisGame.modeTimer += 1
        
        if thisGame.modeTimer == 60:
            thisGame.SetMode( 7 )
            oldEdgeLightColor = thisLevel.edgeLightColor
            oldEdgeShadowColor = thisLevel.edgeShadowColor
            oldFillColor = thisLevel.fillColor
            
    elif thisGame.mode == 7:
        # flashing maze after finishing level
        thisGame.modeTimer += 1
        
        whiteSet = [10, 30, 50, 70]
        normalSet = [20, 40, 60, 80]
        
        if not whiteSet.count(thisGame.modeTimer) == 0:
            # member of white set
            thisLevel.edgeLightColor = (255, 255, 255, 255)
            thisLevel.edgeShadowColor = (255, 255, 255, 255)
            thisLevel.fillColor = (0, 0, 0, 255)
            GetCrossRef()
        elif not normalSet.count(thisGame.modeTimer) == 0:
            # member of normal set
            thisLevel.edgeLightColor = oldEdgeLightColor
            thisLevel.edgeShadowColor = oldEdgeShadowColor
            thisLevel.fillColor = oldFillColor
            GetCrossRef()
        elif thisGame.modeTimer == 150:
            thisGame.SetMode ( 8 )
            
    elif thisGame.mode == 8:
        # blank screen before changing levels
        thisGame.modeTimer += 1
        if thisGame.modeTimer == 10:
            thisGame.SetNextLevel()

    thisGame.SmartMoveScreen(thisLevel)
    
    screen.blit(img_Background, (0, 0))
    
    if not thisGame.mode == 8:
        thisLevel.DrawMap(tileID, tileIDImage)
        
        if thisGame.fruitScoreTimer > 0:
            if thisGame.modeTimer % 2 == 0:
                thisGame.DrawNumber (2500, thisFruit.x - thisGame.screenPixelPos[0] - 16, thisFruit.y - thisGame.screenPixelPos[1] + 4)

        for i in range(0, 4, 1):
            ghosts[i].Draw(thisGame, tileID, tileIDImage, ghosts)
        thisFruit.Draw(thisGame)
        player.Draw(thisGame)
        
        if thisGame.mode == 3:
                screen.blit(thisGame.imHiscores,(32,256))
        
    if thisGame.mode == 5:
        thisGame.DrawNumber (thisGame.ghostValue / 2, player.x - thisGame.screenPixelPos[0] - 4, player.y - thisGame.screenPixelPos[1] + 6)
    
    
    
    thisGame.DrawScore()
    
    pygame.display.flip()
    
    clock.tick (60)

